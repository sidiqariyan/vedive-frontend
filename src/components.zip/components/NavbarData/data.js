export const NavbarMenu = [
    {
     id: 1,
     title: 'Home',
     url: '/',
     active: true,
    },
    {
     id: 2,
     title: 'About Us',
     url: '/about',
        active: true,
    },
    {
        id: 3,
        title: 'Services',
        url: '/services',
        active: true,
    },
    {
        id: 4,
        title: "Pricing",
        url: '/pricing',
        active: true,
    },
    {
        id: 5,
        title: "Templates",
        url: '/templates',
        active: true,
    },
    {
        id: 6,
        title: 'Blogs',
        url: '/blogs',
        active: true,
    },
    {
        id: 7,
        title: 'Contact Us',
        url: '/contact',
        active: true,
    },
    
]